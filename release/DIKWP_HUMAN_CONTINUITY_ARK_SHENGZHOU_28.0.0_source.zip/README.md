# DIKWP HUMAN CONTINUITY ARK / SHENGZHOU 28.0.0

> An offline-first personal and household continuity system for AGI-era functional disruptions.

SHENGZHOU does not assume one cinematic AGI catastrophe. It prepares ordinary people for observable failures: income shock, AI-enabled impersonation, identity lockout, cloud/payment/communications outages, essential-service disruption, autonomous-agent incidents, temporary relocation, and compound crises.

It protects twelve non-compensatory floors: supplies, health, shelter, communication, identity, finance, digital continuity, information integrity, AI authority, mobility, community and psychological continuity.

## Start in one minute

1. Open `release/SHENGZHOU_Personal_AGI_Continuity_Client_28.0.0.html` in a modern browser.
2. Load the synthetic example or enter non-secret household information.
3. Review the weakest floor and weakest world.
4. Complete the six highest-priority actions.
5. Print the emergency card and run one drill.
6. Export a `.hcpkg.json` continuity package each month.

The client is fully offline and requires no account, server, database or model API. Do not enter passwords, authentication codes, private keys, full identity numbers, real family codewords or raw medical records.

## Authority principle

```text
Capability != Authority
Access != Consent
Prediction != Fact
Urgency != Permission
External Automatic Action Authority = 0
```

AI may analyze, organize, simulate and draft locally. Money, contracts, identity, medicine, legal rights, home access, relocation and external communications always require named human confirmation through an independent channel.

## Maturity

Alpha reference implementation and pilot blueprint. It is not an emergency service, medical device, financial product, public-warning system, legal opinion or survival guarantee.
